/* eslint-disable react/jsx-no-target-blank*/
import Box from "@material-ui/core/Box";
import Container from "@material-ui/core/Container";
import Grid from "@material-ui/core/Grid";
// @material-ui/core components
import { makeStyles, useTheme } from "@material-ui/core/styles";
import Typography from "@material-ui/core/Typography";
import badgeStyles from "assets/theme/components/badge.js";
import buttonStyles from "assets/theme/components/button.js";
import componentStyles from "assets/theme/views/index.js";
import AuthFooter from "components/Footers/AuthFooter.js";
import IndexHeader from "components/Headers/IndexHeader.js";
// import ShoppingBasket from "@material-ui/icons/ShoppingBasket";
// core components
import IndexNavbar from "components/Navbars/IndexNavbar.js";
import React from "react";


const useStyles = makeStyles(componentStyles);
const useStylesBadge = makeStyles(badgeStyles);
const useStylesButton = makeStyles(buttonStyles);


export default function Index() {
  const classes = { ...useStyles(), ...useStylesBadge(), ...useStylesButton() };
  const theme = useTheme();
  return (
    <>
      <IndexNavbar />
      <Box position="relative">
        <IndexHeader />
        <Box
          paddingTop="4.5rem"
          paddingBottom="10rem"
          component="section"
          className={classes.bgDefault}
        >
          <Container maxWidth={false}>
            <Grid container className={classes.centerElements}>
              <Grid item xs={12} md={6}>
                <Typography
                  component="h2"
                  variant="h2"
                  className={classes.typographyH2}
                >
                  A complete React solution
                </Typography>
                <Box
                  component="p"
                  color={theme.palette.white.main}
                  fontWeight="300"
                  lineHeight="1.7"
                  fontSize="1.25rem"
                  marginBottom="1rem"
                  marginTop="1.5rem"
                >
                  Argon is a completly new product built on our newest re-built
                  from scratch framework structure that is meant to make our
                  products more intuitive, more adaptive and, needless to say,
                  so much easier to customize. Let Argon amaze you with its cool
                  features and build tools and get your project to a whole new
                  level.
                </Box>
              </Grid>
            </Grid>
          </Container>
        </Box>      
      </Box>
      <AuthFooter />
    </>
  );
}
