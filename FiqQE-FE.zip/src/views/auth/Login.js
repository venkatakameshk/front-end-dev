import { Snackbar } from "@material-ui/core";
import Box from "@material-ui/core/Box";
import Button from "@material-ui/core/Button";
import Card from "@material-ui/core/Card";
import CardContent from "@material-ui/core/CardContent";
import CardHeader from "@material-ui/core/CardHeader";
import Checkbox from "@material-ui/core/Checkbox";
import Container from "@material-ui/core/Container";
import FilledInput from "@material-ui/core/FilledInput";
import FormControl from "@material-ui/core/FormControl";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Grid from "@material-ui/core/Grid";
import IconButton from "@material-ui/core/IconButton";
import InputAdornment from "@material-ui/core/InputAdornment";
// @material-ui/core components
import { makeStyles, useTheme } from "@material-ui/core/styles";
// import PersonIcon from "@material-ui/icons/Person";
// import SuccessIcon from "@material-ui/icons/CheckCircle";
// @material-ui/icons components
import Email from "@material-ui/icons/Email";
import Lock from "@material-ui/icons/Lock";
import ThumbUp from "@material-ui/icons/ThumbUp";
import Visibility from "@material-ui/icons/Visibility";
import VisibilityOff from "@material-ui/icons/VisibilityOff";
import componentStylesButtons from "assets/theme/components/button.js";
import componentStylesSnackbar from "assets/theme/components/snackbar.js";
import hexToRgb from "assets/theme/hex-to-rgb.js";
import componentStyles from "assets/theme/views/auth/login.js";
// core components
import AuthHeader from "components/Headers/AuthHeader.js";
import React from "react";
import { Redirect } from "react-router-dom";

const useStylesSnackbar = makeStyles(componentStylesSnackbar);

const useStyles = makeStyles(componentStyles);
const useStylesButtons = makeStyles(componentStylesButtons);

function Login() {
  const classes = {
    ...useStyles(),
    ...useStylesButtons(),
    ...useStylesSnackbar(),
  };
  const theme = useTheme();
  // const infoSnackbarRootClasses = { root: classes.infoSnackbar };
  // const successSnackbarRootClasses = { root: classes.successSnackbar };
  // const errorSnackbarRootClasses = { root: classes.errorSnackbar };
  // const warningSnackbarRootClasses = { root: classes.warningSnackbar };
  const [username, setUsername] = React.useState(
    localStorage.getItem("username")
  );
  const [password, setPassword] = React.useState("");
  const [showPassword, setShowPassword] = React.useState(false);
  const [rememberMe, setRememberMe] = React.useState(
    Boolean(localStorage.getItem("rememberMe"))
  );
  const [loginSuccess, setLoginSuccess] = React.useState(false);
  const [usernameRequired, setUsernameRequired] = React.useState(false);
  const [passwordRequired, setPasswordRequired] = React.useState(false);
  const [message, setMessage] = React.useState("");
  const [messageType, setMessageType] = React.useState("");
  const [messageClass, setMessageClass] = React.useState("");

  const [openAlert, setOpenAlert] = React.useState(false);
  const handleClickAlert = () => {
    setOpenAlert(true);
  };
  const handleCloseAlert = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }
    setOpenAlert(false);
  };

  const handleLogIn = () => {
    document.body.classList.add("please-wait");

    if (isEmpty(username)) {
      setUsernameRequired(true);
    } else {
      setUsernameRequired(false);
    }
    if (isEmpty(password)) {
      setPasswordRequired(true);
    } else {
      setPasswordRequired(false);
    }

    // setTimeout(() => {
    console.log(`Username:${username} and Password:${password}`);

    if (isEmpty(username) || isEmpty(password)) {
      setMessage("Invalid Sign In details!!");
      setMessageType("Error!");
      setMessageClass({ root: classes.errorSnackbar });
      handleClickAlert();
    } else if (!validateEmail(username)) {
      setMessage("Invalid Email !!");
      setMessageType("Error!");
      setMessageClass({ root: classes.errorSnackbar });
      handleClickAlert();
    } else {
      if (rememberMe && !isEmpty(username)) {
        localStorage.setItem("username", username);
        localStorage.setItem("rememberMe", rememberMe);
      } else {
        localStorage.removeItem("username");
        localStorage.removeItem("rememberMe");
      }
      setMessage("Sign In success!");
      setMessageType("Success!");
      setMessageClass({ root: classes.successSnackbar });
      handleClickAlert();
      setLoginSuccess(true);
    }
    document.body.classList.remove("please-wait");
    // }, 3000);
  };

  const validateEmail = (email) => {
    let validRegex =
      /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

    if (email.match(validRegex)) {
      return true;
    }
    return false;
  };

  // Error handling End..

  const isEmpty = (val) =>
    typeof val === undefined || val === "" || val == null || val.length <= 0
      ? true
      : false;

  const renderLogin = () => {
    return (
      <>
        <AuthHeader
          title="Welcome!"
          description="Use your login credentials or create new account to login."
        />
        {/* Page content */}
        <Container
          component={Box}
          maxWidth="xl"
          marginTop="-8rem"
          paddingBottom="3rem"
          position="relative"
          zIndex="101"
        >
          <Box component={Grid} container justifyContent="center">
            <Grid item xs={12} lg={5} md={7}>
              <Card classes={{ root: classes.cardRoot }}>
                <CardHeader
                  className={classes.cardHeader}
                  title={
                    <Box
                      fontSize="80%"
                      fontWeight="700"
                      component="small"
                      color={theme.palette.gray[600]}
                    >
                      Sign In
                    </Box>
                  }
                  titleTypographyProps={{
                    component: Box,
                    textAlign: "center",
                    marginBottom: "1rem!important",
                    marginTop: ".5rem!important",
                    fontSize: "1rem!important",
                  }}
                  // subheader={
                  //   <Box textAlign="center">
                  //     <Box
                  //       component={Button}
                  //       variant="contained"
                  //       marginRight=".5rem!important"
                  //       classes={{ root: classes.buttonRoot }}
                  //     >
                  //       <Box component="span" marginRight="4px">
                  //         <Box
                  //           alt="..."
                  //           component="img"
                  //           width="20px"
                  //           className={classes.buttonImg}
                  //           src={
                  //             require("assets/img/icons/common/github.svg")
                  //               .default
                  //           }
                  //         ></Box>
                  //       </Box>
                  //       <Box component="span" marginLeft=".75rem">
                  //         Github
                  //       </Box>
                  //     </Box>
                  //     <Button
                  //       variant="contained"
                  //       classes={{ root: classes.buttonRoot }}
                  //     >
                  //       <Box component="span" marginRight="4px">
                  //         <Box
                  //           alt="..."
                  //           component="img"
                  //           width="20px"
                  //           className={classes.buttonImg}
                  //           src={
                  //             require("assets/img/icons/common/google.svg")
                  //               .default
                  //           }
                  //         ></Box>
                  //       </Box>
                  //       <Box component="span" marginLeft=".75rem">
                  //         Google
                  //       </Box>
                  //     </Button>
                  //   </Box>
                  // }
                ></CardHeader>
                <CardContent classes={{ root: classes.cardContent }}>
                  {/* <Box
                  color={theme.palette.gray[600]}
                  textAlign="center"
                  marginBottom="1rem"
                  marginTop=".5rem"
                  fontSize="1rem"
                >
                  <Box fontSize="80%" fontWeight="400" component="small">
                    Or sign in with credentials
                  </Box>
                </Box> */}
                  <FormControl
                    variant="filled"
                    component={Box}
                    width="100%"
                    marginBottom="1rem!important"
                  >
                    <FilledInput
                      autoComplete="off"
                      type="email"
                      placeholder="Email"
                      inputProps={{
                        value: username,
                      }}
                      startAdornment={
                        <InputAdornment position="start">
                          <Email />
                        </InputAdornment>
                      }
                      error={usernameRequired}
                      onChange={(e) => {
                        setUsername(e.target.value);
                        if (isEmpty(e.target.value)) {
                          setUsernameRequired(true);
                        } else {
                          setUsernameRequired(false);
                        }
                      }}
                    />
                  </FormControl>
                  <FormControl
                    variant="filled"
                    component={Box}
                    width="100%"
                    marginBottom="1rem!important"
                  >
                    <FilledInput
                      autoComplete="off"
                      type={showPassword ? "text" : "password"}
                      placeholder="Password"
                      inputProps={{
                        value: password,
                      }}
                      error={passwordRequired}
                      startAdornment={
                        <InputAdornment position="start">
                          <Lock />
                        </InputAdornment>
                      }
                      onChange={(e) => {
                        setPassword(e.target.value);
                        if (isEmpty(e.target.value)) {
                          setPasswordRequired(true);
                        } else {
                          setPasswordRequired(false);
                        }
                      }}
                      endAdornment={
                        <InputAdornment position="end">
                          <IconButton
                            onClick={() => {
                              setShowPassword(!showPassword);
                            }}
                            onMouseDown={(e) => {
                              e.preventDefault();
                            }}
                          >
                            {showPassword ? <Visibility /> : <VisibilityOff />}
                          </IconButton>
                        </InputAdornment>
                      }
                    />
                  </FormControl>
                  <FormControlLabel
                    value="end"
                    control={
                      <Checkbox
                        color="primary"
                        checked={rememberMe}
                        onChange={(e) => {
                          setRememberMe(e.target.value);
                        }}
                      />
                    }
                    label="Remember me"
                    labelPlacement="end"
                    classes={{
                      root: classes.formControlLabelRoot,
                      label: classes.formControlLabelLabel,
                    }}
                  />
                  <Box
                    textAlign="center"
                    marginTop="1.5rem"
                    marginBottom="1.5rem"
                  >
                    <Button
                      variant="contained"
                      classes={{ root: classes.buttonContainedInfo }}
                      onClick={handleLogIn}
                    >
                      Let's go
                    </Button>
                  </Box>
                </CardContent>
              </Card>
              <Grid container component={Box} marginTop="1rem">
                <Grid item xs={6} component={Box} textAlign="left">
                  <a
                    href="#admui"
                    onClick={(e) => e.preventDefault()}
                    className={classes.footerLinks}
                  >
                    Forgot password
                  </a>
                </Grid>
                <Grid item xs={6} component={Box} textAlign="right">
                  <a href="/auth/register" className={classes.footerLinks}>
                    Create new account
                  </a>
                </Grid>
              </Grid>
            </Grid>
          </Box>
        </Container>
      </>
    );
  };
  const renderSnackbar = () => (
    <Snackbar
      anchorOrigin={{
        vertical: "bottom",
        horizontal: "center",
      }}
      open={openAlert}
      autoHideDuration={2000}
      onClose={handleCloseAlert}
      ContentProps={{
        classes: messageClass,
        elevation: 1,
      }}
      action={
        <Box
          component={IconButton}
          padding="0!important"
          onClick={handleCloseAlert}
        >
          <Box
            component="span"
            color={"rgba(" + hexToRgb(theme.palette.white.main) + ",.6)"}
          >
            ×
          </Box>
        </Box>
      }
      message={
        <>
          <Box
            fontSize="1.25rem"
            display="flex"
            marginRight="1.25rem"
            alignItems="center"
          >
            <Box
              component={ThumbUp}
              width="1.25rem!important"
              height="1.25rem!important"
            />
          </Box>
          <Box component="span">
            <Box component="strong" marginRight=".5rem">
              {messageType}
            </Box>
            {message}
          </Box>
        </>
      }
    />
  );

  const render = () => {
    if (loginSuccess) {
      return <Redirect to="/admin" />;
    } else{
      return (
        <>
          {renderLogin()}
          {renderSnackbar()}
        </>
      );
    }
    
  };

  return render();
}

export default Login;
