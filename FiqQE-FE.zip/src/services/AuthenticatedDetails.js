class AuthenticatedDetails {
  authUser = "";
  authToken = "";

  setAuthUser(authUser) {
    this.authUser = authUser;
  }

  getAuthUser() {
    return this.authUser;
  }

  setAuthToken(authToken) {
    this.authToken = authToken;
  }

  getAuthToken() {
    return this.authToken;
  }
}
export default new AuthenticatedDetails();
