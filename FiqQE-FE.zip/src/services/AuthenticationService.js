class AuthenticationService {
  isAuthenticated() {
    return true;
  }
}
export default new AuthenticationService();
